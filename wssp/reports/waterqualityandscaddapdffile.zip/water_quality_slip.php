<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="container">	
		<div class=""><br>
			<table border="1" width="100%">
				<tr>
					<td width="100px"><img src="wssp-logo.png" width="100%"></td>
					<td class="text-center"><h5>WATER & SANITATION SERVICES PESHAWAR (WSSP) GOVERNMENT OF KHYBER PAKHTUNKHWA LCB building Plot No. 33 Street No. 13 Sector E-8, Phase 7 Hayatabad, Peshawar</h5>	
					<h6>Office Phone # 091-9219018</h6></td>
					<td width="100px"><img src="logo.png" width="100%"></td>
				</tr>
			</table>	
		</div>
		<div class="row">
			<div class="col col-md-3 offset-md-9">	
				<b><?php date_default_timezone_set('Asia/Karachi');
				 echo date("d-m-Y H:i:s");?></b><br>	
			</div>
		</div>
		<div class="row">
			<div class="col col-md-12">
				<u><h5 style="text-align: center;">DRINKING WATER ANALYSIS REPORT</h5></u>
			</div>
		</div>
		<br>
		<div class="row table">
			<table border="1" class="table table-bordered">
				<tr>
					<td colspan="2">Device Location:_______</td>
					<td colspan="1">UC:______</td>
					<td colspan="2">Connected Tube Well Name:___________</td>
				</tr>
				<tr>
					<td colspan="2">Date of Sampling:_______</td>
					<td colspan="1">Time of Sampling:______</td>
					<td colspan="2">No. of Sample:___________</td>
				</tr>
				<tr>
					<td colspan="5"></td>		
				</tr>
				<tr>
					<td><b>Parameters</td>
					<td><b>Unit</td>
					<td><b>Values</td>
					<td><b>WHO Standard Range</td>
					<td><b>Remarks</td>
				</tr>
				<tr>
					<td>Turbidity</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td>Total Dissolved Solids</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>PH </b></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
					<tr>
					<td>Conductivity</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
			</table>
		</div>
		<br><br><br>
		<div class="row">
			<div class="col col-md-4">
				<B>Remarks:</B>
			</div>
		</div>
		<br>
		<br>
		<div class="row offset-md-3">
			<h6 style="text-align: center;">This is a computer-generated report and does not require a signature</h6>
		</div>
		<br>	
	</div>
</body>
</html>